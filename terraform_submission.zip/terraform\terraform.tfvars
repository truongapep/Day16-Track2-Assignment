ubuntu_ami_id = "ami-075a5b973dac51741"
